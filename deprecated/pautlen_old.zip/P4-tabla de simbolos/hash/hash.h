#ifndef HASH_H
#define HASH_H

int procesar(char* input);

#endif