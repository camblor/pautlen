#define _GNU_SOURCE

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include "hash/hash.h"


#define SIZE 100

int main()
{
    procesar("entrada");
    exit(EXIT_SUCCESS);
}