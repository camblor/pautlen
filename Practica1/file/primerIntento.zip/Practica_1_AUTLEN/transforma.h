#ifndef TRANSFORMA_H
#define TRANSFORMA_H

#include <stdio.h>

#include "afnd.h"

AFND * AFNDTransforma(AFND * p_afnd);

#endif
